<?php 
$flashBacktransparent		= '';
$flashBackcolor				= 'ffffff';
$buttonsBG					= '565f68';
$buttonsMouseOver			= '74c20e';
$buttonsMouseOut			= 'ffffff';
$catButtonsMouseOver		= '565f68';
$catButtonsMouseOut			= '565f68';
$catButtonsTextMouseOver	= '74c20e';
$catButtonsTextMouseOut		= 'ffffff';
$thumbMouseOver				= '99d24e';
$thumbMouseOut				= '565f68';
$mainTitle					= '000000';
$categoryTitle				= '74c20e';
$itemBG						= '565f68';
$itemTitle					= '74c20e';
$itemDescription			= '565f68';
?>