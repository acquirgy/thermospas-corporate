How to upgrade plugin to commercial version:

1. Install the latest version of "1 Flash Gallery" plugin from:
http://wordpress.org/extend/plugins/1-flash-gallery/

2. Install "1-flash-gallery-update-xxxx" plugin. 
You can download it from personal account

*Important* You don't need to uninstall free version, when install commercial one. You need them both to be installed as separate plugins

